import os

# Directory to store ECC key pairs
KEYS_DIR = "keys"

# Replay Attack Protection
NONCE_LENGTH = 16  # 16-byte random nonce

# Log file
LOG_FILE = "security_system.log"
